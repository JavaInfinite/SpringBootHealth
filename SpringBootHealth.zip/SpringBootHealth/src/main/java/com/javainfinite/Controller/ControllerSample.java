package com.javainfinite.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerSample {
	@GetMapping(value = "/")
	public String showStatus() {
		return "Lets check ";
	}
}
